WASD or Arrow Keys to move.

Once the 12 cubes have been collected, "You Win!" will appear onscreen. This will not go away, and will not close the game.

To close the game, simply press the X in the top right of the window. ESCAPE will not work. Alternatively, Alt+F4 will close the game.